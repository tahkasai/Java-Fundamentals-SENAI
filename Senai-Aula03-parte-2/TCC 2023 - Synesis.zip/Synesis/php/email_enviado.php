<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="favicon.ico" type="image/logo.png">
    <title>Email enviado</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>

    <div class="pag_login">
        <div class="conteiner_login">
            <form id="emailrecp">
                <div class="centro">
                    <br><h2> E-mail enviado</h2><br><br>
                    <p> O link de recuperação de senha foi enviado para seu e-mail!!<br><br> Altere a senha e volte para fazer o login! </p><br><br>
                </div>
            </form>
        </div>
    </div>
    
</body>
</html>